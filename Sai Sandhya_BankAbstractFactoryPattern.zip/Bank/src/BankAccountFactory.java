interface BankAccountFactory {
    BankAccount createAccount();
}
