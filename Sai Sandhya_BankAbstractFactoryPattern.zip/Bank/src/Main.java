public class Main {
    public static void main(String[] args) {
        BankAccountFactory loanFactory = new LoanAccountFactory();
        BankAccountFactory savingsFactory = new SavingsAccountFactory();

        BankAccount loanAccount = loanFactory.createAccount();
        BankAccount savingsAccount = savingsFactory.createAccount();

        loanAccount.setInterestRate(0.07); // Changing loan interest rate to 7%

        System.out.println("Loan Account Interest Rate: " + loanAccount.getInterestRate());
        System.out.println("Savings Account Interest Rate: " + savingsAccount.getInterestRate());
    }
}
