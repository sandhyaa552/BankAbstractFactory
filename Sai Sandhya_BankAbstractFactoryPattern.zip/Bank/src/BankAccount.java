interface BankAccount {
    void setInterestRate(double interestRate);
    double getInterestRate();
}
